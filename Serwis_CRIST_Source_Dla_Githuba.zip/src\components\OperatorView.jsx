import { useState, useEffect, useRef } from 'react';
import { collection, onSnapshot, addDoc, doc, getDoc, serverTimestamp, setDoc } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { signInAnonymously, onAuthStateChanged } from 'firebase/auth';
import jsQR from 'jsqr';
import { Html5Qrcode } from 'html5-qrcode';
import OperatorForm from './OperatorForm';
import { useManagerStore } from '../store/managerStore';

export default function OperatorView({ user, onLogout, initialMachineId, onSwitchView }) {
  const tenantId = useManagerStore(state => state.tenantId) || new URLSearchParams(window.location.search).get('tenant') || import.meta.env.VITE_DEFAULT_TENANT || 'crist';
  const [machines, setMachines] = useState([]);
  const [regions, setRegions] = useState([]);
  const [topicsList, setTopicsList] = useState([]);
  const [reportersList, setReportersList] = useState([]);
  const [step, setStep] = useState(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('step') || 'scan';
  }); // 'scan', 'form', 'success'
  const [selectedMachine, setSelectedMachine] = useState(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null); // Do debuggowania na telefonie

  // Obsługa przycisku Wstecz (Popstate)
  useEffect(() => {
    window.history.replaceState({ step: step }, '', `?module=operator&step=${step}`);
    const handlePopState = (e) => {
      if (e.state && e.state.step) {
        setStep(e.state.step);
      }
    };
    window.addEventListener('popstate', handlePopState);
return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handleStepChange = (newStep) => {
    setStep(newStep);
    window.history.pushState({ step: newStep }, '', `?module=operator&step=${newStep}`);
  };
  const [isLiveScanning, setIsLiveScanning] = useState(false);
  const [nfcStatus, setNfcStatus] = useState("unsupported");
  const nfcAbortControllerRef = useRef(null);
  const html5QrcodeRef = useRef(null);

  // Status sieci
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Formularz

  // Pobieranie maszyn i tematów
  useEffect(() => {
    let unsubscribeMachines = () => {};
    let unsubscribeTopics = () => {};
    let unsubscribeReporters = () => {};
    let unsubscribeRegions = () => {};
    let authUnsub = () => {};

    try {
      if (!auth.currentUser) {
        signInAnonymously(auth).catch((error) => console.error("Anonymous login error:", error));
      }

      authUnsub = onAuthStateChanged(auth, (authUser) => {
        if (authUser) {
          // Firebase Auth confirms we have a token, safe to attach listeners

      unsubscribeMachines = onSnapshot(collection(db, 'tenants', tenantId, 'machines'), async (querySnapshot) => {
        const machinesData = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })).filter(m => !m.isDeleted);
        setMachines(machinesData);

        if (initialMachineId && step === 'scan') {
          const targetMachine = machinesData.find(m => m.id === initialMachineId);
          if (targetMachine) {
            setSelectedMachine(targetMachine);
            handleStepChange('form');
          } else {
            const docRef = doc(db, 'tenants', (useManagerStore.getState().tenantId || import.meta.env.VITE_DEFAULT_TENANT || 'crist'), 'machines', initialMachineId);
            const docSnap = await getDoc(docRef);
            if (docSnap.exists()) {
              setSelectedMachine({ id: docSnap.id, ...docSnap.data() });
              handleStepChange('form');
            } else {
              alert("Błąd: Nie znaleziono maszyny z URL o ID: " + initialMachineId);
            }
          }
        }
      }, (error) => console.error("SNAPSHOT ERROR FOR machines:", error));

      unsubscribeTopics = onSnapshot(collection(db, 'tenants', tenantId, 'topics'), (querySnapshot) => {
        setTopicsList(querySnapshot.docs.map(d => d.data()).filter(d => !d.isDeleted).map(d => d.text));
      }, (error) => console.error("SNAPSHOT ERROR FOR topics:", error));

      unsubscribeReporters = onSnapshot(collection(db, 'tenants', tenantId, 'reporters'), (querySnapshot) => {
        setReportersList(querySnapshot.docs.map(d => ({ id: d.id, ...d.data() })).filter(r => !r.isDeleted));
      }, (error) => console.error("SNAPSHOT ERROR FOR reporters:", error));

      unsubscribeRegions = onSnapshot(collection(db, 'tenants', tenantId, 'regions'), (querySnapshot) => {
        setRegions(querySnapshot.docs.map(d => ({ id: d.id, ...d.data() })).filter(r => !r.isDeleted));
      }, (error) => console.error("SNAPSHOT ERROR FOR regions:", error));
              }
        });
      } catch (error) {
      console.error("Błąd inicjalizacji:", error);
      setErrorMsg("Krytyczny błąd: " + error.message);
    }
    return () => {
      unsubscribeMachines();
      unsubscribeTopics();
      unsubscribeReporters();
      unsubscribeRegions();
        if (authUnsub) authUnsub();
    };
  }, [initialMachineId]);

  const machinesRef = useRef([]);
  useEffect(() => {
    machinesRef.current = machines;
  }, [machines]);

    const startLiveScanner = () => {
    setIsLiveScanning(true);
    setErrorMsg(null);
  };


  const startNfcLive = async () => {
    if (!('NDEFReader' in window)) {
        alert("Twoja przeglądarka nie wspiera Web NFC.");
        return;
    }
    
    // Anuluj poprzednie skanowanie jeśli istnieje
    if (nfcAbortControllerRef.current) {
      nfcAbortControllerRef.current.abort();
    }
    nfcAbortControllerRef.current = new AbortController();

    try {
      const ndef = new window.NDEFReader();
      await ndef.scan({ signal: nfcAbortControllerRef.current.signal });
      setNfcStatus('active');
      
      ndef.addEventListener("reading", event => {
        try {
          const decoder = new TextDecoder();
          for (const record of event.message.records) {
            let decodedText = decoder.decode(record.data);
            
            let machineId = decodedText;
            let tenantFromQr = null;
            if (decodedText.includes('?')) {
              try {
                const urlParams = new URLSearchParams(decodedText.split('?')[1]);
                machineId = urlParams.get('machine') || machineId;
                tenantFromQr = urlParams.get('tenant');
              } catch (e) {}
            }

            if (tenantFromQr && tenantFromQr !== tenantId) {
              window.location.href = decodedText;
              return;
            }

            machineId = typeof machineId === 'string' ? machineId.trim() : machineId;
            machineId = machineId.replace(/^[^\w]+/, ''); // FIX: usuwamy tylko znaki BĘDĄCE NIE-LITERAMI z początku
            
            if (machineId) {
              if (machineId === initialMachineId) {
                const targetMachine = machinesRef.current.find(m => 
                    m.id === machineId || 
                    (m.qrCode && (m.qrCode === machineId || m.qrCode === decodedText)) || 
                    (m.internalId && m.internalId.toLowerCase() === machineId.toLowerCase())
                  );
                if (targetMachine) { 
                  setSelectedMachine(targetMachine); 
                  stopNfcLive(); 
                  handleStepChange('form'); 
                }
              } else {
                const foundMachine = machinesRef.current.find(m => 
                    m.id === machineId || 
                    (m.qrCode && (m.qrCode === machineId || m.qrCode === decodedText)) || 
                    (m.internalId && m.internalId.toLowerCase() === machineId.toLowerCase())
                  );
                if (foundMachine) { 
                  setSelectedMachine(foundMachine); 
                  stopNfcLive(); 
                  handleStepChange('form'); 
                } else { 
                  alert('Nie znaleziono maszyny: ' + machineId); 
                  stopNfcLive(); 
                  handleStepChange('scan'); 
                }
              }
            } else { alert('Nieprawidłowy odczyt NFC'); }
          }
        } catch (e) {
          console.error("Błąd dekodowania NFC:", e);
          alert("Błąd dekodowania NFC: " + e.message);
        }
      });
      
      ndef.addEventListener("readingerror", () => {
          alert("NFC nie mogło odczytać tagu.");
      });
    } catch (error) {
      console.error("NFC start error:", error);
      alert("NFC Error: " + error.message);
      setNfcStatus('error');
    }
  };

  const stopNfcLive = () => {
    if (nfcAbortControllerRef.current) {
      nfcAbortControllerRef.current.abort();
      nfcAbortControllerRef.current = null;
    }
    setNfcStatus('unsupported');
  };

  const stopLiveScanner = () => {
    setIsLiveScanning(false);
  };

    useEffect(() => {
    if (isLiveScanning) {
      const html5QrCode = new Html5Qrcode('qr-reader');
      html5QrcodeRef.current = html5QrCode;
      html5QrCode.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        (decodedText) => {
          stopLiveScanner();
          let machineId = decodedText;
            let tenantFromQr = null;
            if (decodedText.includes('?')) {
              const urlParams = new URLSearchParams(decodedText.split('?')[1]);
              machineId = urlParams.get('machine') || machineId;
              tenantFromQr = urlParams.get('tenant');
            }
            
            // Walidacja cross-tenant dla operatora (live scanner w apce)
            if (tenantFromQr && tenantFromQr !== tenantId) {
              // Anonimowy operator skanujący inna firmę z poziomu apki -> przekierowanie do tej firmy (przeładowanie PWA w kontekście nowej firmy)
              window.location.href = decodedText;
              return;
            }
          if (machineId) {
            if (machineId === initialMachineId) {
              const targetMachine = machinesRef.current.find(m => 
                  m.id === machineId || 
                  (m.qrCode && (m.qrCode === machineId || m.qrCode === decodedText)) || 
                  (m.internalId && m.internalId.toLowerCase() === machineId.toLowerCase())
                );
              if (targetMachine) { setSelectedMachine(targetMachine); handleStepChange('form'); }
            } else {
              const foundMachine = machinesRef.current.find(m => 
                  m.id === machineId || 
                  (m.qrCode && (m.qrCode === machineId || m.qrCode === decodedText)) || 
                  (m.internalId && m.internalId.toLowerCase() === machineId.toLowerCase())
                );
              if (foundMachine) { setSelectedMachine(foundMachine); handleStepChange('form'); }
              else { alert('Nie znaleziono maszyny: ' + machineId); handleStepChange('scan'); }
            }
          } else { alert('Nieprawidlowy QR'); }
        },
        () => {}
      ).catch(err => {
          console.error('Scanner error:', err);
          setErrorMsg(err.message || 'Błąd uruchamiania kamery.');
        });
        
        return () => {
          
          if (html5QrcodeRef.current) { try { html5QrcodeRef.current.stop().catch(()=>{}); } catch(e) {} }
          const container = document.getElementById('qr-reader');
          if (container) container.innerHTML = '';
        };
      }
  }, [isLiveScanning, initialMachineId]);
  const handleFileScan = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        // Skalowanie obrazu
        let w = img.width;
        let h = img.height;
        if (w > 1200 || h > 1200) {
          const ratio = Math.min(1200 / w, 1200 / h);
          w = w * ratio;
          h = h * ratio;
        }
        canvas.width = w;
        canvas.height = h;
        context.drawImage(img, 0, 0, w, h);
        
        const imageData = context.getImageData(0, 0, w, h);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: "attemptBoth",
        });

        if (code) {
          let machineId = code.data;
          if (code.data.includes('?machine=')) {
            const urlParams = new URLSearchParams(code.data.split('?')[1]);
            machineId = urlParams.get('machine');
          }
          const currentMachines = machinesRef.current;
          const foundMachine = currentMachines.find(m => m.id === machineId);
          if (foundMachine) {
            setSelectedMachine(foundMachine);
            handleStepChange('form');
          } else {
            alert('Nie znaleziono maszyny: ' + machineId);
            handleStepChange('scan');
          }
        } else {
          setErrorMsg('Nie wykryto kodu QR na zdjęciu. Spróbuj jeszcze raz (zrób wyraźne zdjęcie).');
        }
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  };


  const resetFlow = () => {
    
    
    
    setSelectedMachine(null);
    setErrorMsg(null);
    if (initialMachineId) {
      window.history.replaceState({}, document.title, window.location.pathname);
    }
    handleStepChange('scan');
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col relative">


      <header className="bg-blue-900 text-white p-4 flex justify-between items-center shadow-md">
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-bold flex items-center gap-2">
            Zgłoś Awarię
            <span className={`w-3 h-3 rounded-full ${isOnline ? 'bg-green-400' : 'bg-orange-400'} animate-pulse`}></span>
          </h1>
        </div>
        <div className="flex items-center gap-2">
          {onSwitchView && (
            <button 
              onClick={onSwitchView} 
              className="flex items-center gap-2 bg-yellow-500 hover:bg-yellow-400 text-yellow-900 font-bold px-3 py-2 rounded transition-colors shadow-sm"
              title="Wróć do Dyspozytorni"
            >
              <i className="ph ph-desktop text-xl"></i>
              <span className="hidden sm:inline">Dyspozytornia</span>
            </button>
          )}
          <button onClick={onLogout} className="flex items-center gap-2 bg-blue-800 hover:bg-blue-700 px-3 py-2 rounded transition-colors text-sm sm:text-base">
            <i className="ph ph-sign-out text-xl"></i>
            <span>Wyjdź</span>
          </button>
        </div>
      </header>

      <main className="flex-1 p-4 max-w-2xl mx-auto w-full mt-4">
        
        {/* Kontener na błędy (Logowanie błędów na ekranie) */}
        {errorMsg && (
          <div className="mb-4 bg-red-100 border-l-4 border-red-600 text-red-900 p-4 rounded shadow-sm">
            <h3 className="font-bold text-sm">Log błędu systemu:</h3>
            <p className="text-xs font-mono break-words mt-1">{errorMsg}</p>
          </div>
        )}

        {step === 'scan' && (
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 text-center">
            <h2 className="text-xl font-black mb-6 uppercase tracking-wider text-slate-800">OPCJE ZGŁOSZEŃ</h2>
              
              {nfcStatus === 'active' ? (
                  <div className="bg-slate-50 p-8 rounded-2xl shadow-sm border-2 border-dashed border-slate-200 text-center flex flex-col items-center justify-center gap-6">
                    <div className="relative">
                      <div className="absolute inset-0 bg-purple-400 rounded-full animate-ping opacity-20"></div>
                      <div className="w-24 h-24 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center shadow-lg relative z-10">
                        <i className="ph ph-waves text-6xl"></i>
                      </div>
                    </div>
                    <div>
                      <h4 className="text-xl font-black uppercase tracking-wider text-slate-800">NFC Aktywne</h4>
                      <p className="text-slate-500 mt-2 font-medium">Zbliż plecki telefonu do naklejki NFC.</p>
                    </div>
                    <button 
                      onClick={stopNfcLive}
                      className="mt-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold px-6 py-2 rounded-xl transition-colors"
                    >
                      Anuluj
                    </button>
                  </div>
                ) : isLiveScanning ? (
                  <div className="bg-slate-900 p-4 rounded-xl shadow-lg border border-slate-700">
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-white font-bold text-sm flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span>
                        Skaner aparatu
                      </span>
                      <button 
                        onClick={stopLiveScanner}
                        className="bg-red-600 hover:bg-red-700 text-white text-xs font-bold px-3 py-1.5 rounded transition-colors"
                      >
                        Zamknij kamerę
                      </button>
                    </div>
                    <div id="qr-reader" className="w-full rounded-lg overflow-hidden bg-black min-h-[250px]"></div>
                  </div>
                ) : (
                <div className="space-y-4">
                  <div className="flex gap-4 max-w-md mx-auto w-full">
                      {/* Skanuj QR */}
                      <button
                        onClick={startLiveScanner}
                        className="flex-1 py-5 px-2 bg-gradient-to-br from-[#1b5fcc] to-[#3a7dfc] hover:opacity-90 text-white rounded-2xl font-bold shadow-lg transition-all flex flex-col items-center justify-center gap-3 relative overflow-hidden group"
                      >
                        <div className="relative w-16 h-16 flex items-center justify-center rounded-xl overflow-hidden">
                          <i className="ph ph-qr-code text-[60px] text-white/90"></i>
                        </div>
                        <span className="text-xl tracking-wide">Skanuj QR</span>
                      </button>

                      {/* Skanuj NFC */}
                      <button
                        onClick={startNfcLive}
                        className="flex-1 py-5 px-2 bg-gradient-to-br from-[#6b21a8] to-[#a855f7] hover:opacity-90 text-white rounded-2xl font-bold shadow-lg transition-all flex flex-col items-center justify-center gap-3 relative overflow-hidden group"
                      >
                        <div className="relative w-16 h-16 flex items-center justify-center rounded-xl overflow-hidden">
                          <i className="ph ph-waves text-[60px] text-white/90"></i>
                        </div>
                        <span className="text-xl tracking-wide">Odczyt NFC</span>
                      </button>
                    </div>

                  <div className="flex flex-col gap-3 mt-6 text-left">
                    <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex gap-4 items-center transition-all hover:shadow-md">
                      <div className="w-16 h-16 shrink-0 bg-slate-50 rounded-lg flex items-center justify-center text-slate-700 relative border border-slate-100">
                        <i className="ph ph-device-mobile-camera text-4xl"></i>
                        <i className="ph ph-wrench text-lg absolute -bottom-1 -right-1 text-slate-800 bg-white rounded-full p-0.5 shadow-sm border border-slate-100"></i>
                      </div>
                      <div>
                        <h3 className="font-bold text-sm sm:text-base text-slate-800 uppercase tracking-tight">1. Zgłoś tę maszynę (Standard):</h3>
                        <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-snug">Zeskanuj kod QR bezpośrednio na urządzeniu i zgłoś usterkę.</p>
                      </div>
                    </div>

                    <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex gap-4 items-center transition-all hover:shadow-md">
                      <div className="w-16 h-16 shrink-0 bg-slate-50 rounded-lg flex items-center justify-center text-slate-700 relative border border-slate-100">
                        <i className="ph ph-qr-code text-4xl"></i>
                        <i className="ph ph-plus-circle text-lg absolute -bottom-1 -right-1 text-slate-800 bg-white rounded-full p-0.5 shadow-sm border border-slate-100"></i>
                      </div>
                      <div>
                        <h3 className="font-bold text-sm sm:text-base text-slate-800 uppercase tracking-tight">2. Zgłoś inną maszynę:</h3>
                        <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-snug">Użyj dowolnego kodu QR, aby wskazać inną maszynę lub dodać nową (dla dowolnego rejonu).</p>
                      </div>
                    </div>

                    <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex gap-4 items-center transition-all hover:shadow-md">
                      <div className="w-16 h-16 shrink-0 bg-slate-50 rounded-lg flex items-center justify-center text-slate-700 relative border border-slate-100">
                        <i className="ph ph-device-mobile text-4xl"></i>
                        <i className="ph ph-wifi-high text-xl absolute top-0 right-0 text-blue-500 animate-pulse"></i>
                        <span className="absolute bottom-1 right-1 text-[9px] font-black bg-slate-800 text-white px-1 rounded">NFC</span>
                      </div>
                      <div>
                        <h3 className="font-bold text-sm sm:text-base text-slate-800 uppercase tracking-tight">3. Szybki odczyt NFC:</h3>
                        <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-snug">Zamiast skanować aparatem, włącz NFC i przyłóż telefon do znacznika.</p>
                      </div>
                    </div>
                  </div>
                </div>
            )}
            
            
          </div>
        )}
        
        {step === 'form' && !selectedMachine && (
          <div className="bg-white p-12 rounded-lg shadow-sm border border-gray-200 text-center flex flex-col items-center justify-center">
            <i className="ph ph-spinner-gap animate-spin text-4xl text-blue-600 mb-4"></i>
            <h2 className="text-xl font-semibold text-gray-800">Wczytywanie maszyny...</h2>
            <p className="text-gray-500 text-sm mt-2">Pobieranie danych z systemu bazy maszyn.</p>
          </div>
        )}

        {step === 'form' && selectedMachine && (
          <OperatorForm
            selectedMachine={selectedMachine}
            setSelectedMachine={setSelectedMachine}
            regions={regions}
            initialMachineId={initialMachineId}
            handleStepChange={handleStepChange}
            isOnline={isOnline}
            topicsList={topicsList}
            reportersList={reportersList}
            stopLiveScanner={stopLiveScanner}
          />
        )}
        {step === 'success' && (
          <div className="bg-white p-8 sm:p-12 rounded-3xl shadow-xl flex flex-col items-center justify-center text-center animate-fade-in border border-emerald-100 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-2 bg-emerald-500"></div>
            <div className="w-24 h-24 bg-emerald-100 text-emerald-500 rounded-full flex items-center justify-center mb-6 shadow-inner">
              <i className="ph ph-check-circle text-6xl"></i>
            </div>
            <h2 className="text-3xl font-extrabold text-gray-900 mb-4 tracking-tight">Gotowe!</h2>
            <p className="text-gray-600 mb-8 max-w-sm text-lg leading-relaxed">
              Zgłoszenie awarii maszyny <span className="font-bold text-gray-800">{selectedMachine?.name}</span> zostało pomyślnie wysłane.
            </p>
            
            <button 
              onClick={() => {
                setSelectedMachine(null);
                handleStepChange('scan');
              }} 
              className="w-full sm:w-auto bg-gray-900 hover:bg-gray-800 text-white font-bold py-4 px-10 rounded-xl transition-all uppercase tracking-widest text-sm shadow-xl shadow-gray-900/20 active:scale-95"
            >
              Zgłoś kolejną awarię
            </button>
            
          </div>
        )}
      </main>
    </div>
  );
}
